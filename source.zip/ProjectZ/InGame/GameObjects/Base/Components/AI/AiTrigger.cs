﻿using Microsoft.Xna.Framework;

namespace ProjectZ.InGame.GameObjects.Base.Components.AI
{
    class AiTrigger
    {
        public virtual void OnInit() { }

        public virtual void Update() { }
    }
}
