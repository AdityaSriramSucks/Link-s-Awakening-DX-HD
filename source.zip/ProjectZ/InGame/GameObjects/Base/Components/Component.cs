﻿namespace ProjectZ.InGame.GameObjects.Base.Components
{
    public class Component
    {
        public GameObject Owner;
        public static int Index;
    }
}
